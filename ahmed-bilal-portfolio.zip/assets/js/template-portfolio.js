"use strict";
const menuButton = document.querySelector('.menu-toggle');
const navigation = document.querySelector('#navigation');
function closeMenu(returnFocus = false) {
  const wasOpen = menuButton.getAttribute('aria-expanded') === 'true';
  navigation.classList.remove('is-open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.querySelector('span').textContent = '+';
  if (returnFocus && wasOpen) menuButton.focus();
}
menuButton.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true';
  navigation.classList.toggle('is-open', open);
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.querySelector('span').textContent = open ? '−' : '+';
});
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(true); });
document.addEventListener('click', event => { if (!event.target.closest('.ab-header')) closeMenu(); });
document.addEventListener('focusin', event => { if (!event.target.closest('.ab-header')) closeMenu(); });
matchMedia('(min-width: 768px)').addEventListener('change', () => closeMenu());
const header = document.querySelector('.ab-header');
let scrollQueued = false;
function updateHeader() {
  header.classList.toggle('is-scrolled', window.scrollY > 40);
  let current = null;
  navigation.querySelectorAll('a').forEach(link => {
    const section = document.querySelector(link.getAttribute('href'));
    const bounds = section.getBoundingClientRect();
    if (bounds.top <= 150 && bounds.bottom > 150) current = link;
    link.removeAttribute('aria-current');
  });
  if (current) current.setAttribute('aria-current','location');
  scrollQueued = false;
}
window.addEventListener('scroll', () => { if (!scrollQueued) { scrollQueued = true; requestAnimationFrame(updateHeader); } }, {passive:true});
updateHeader();
const dialog = document.querySelector('#gallery');
const galleryImage = document.querySelector('#gallery-image');
const galleryThumbnails = document.querySelector('#gallery-thumbnails');
const screenCatalog = {
  Kobopay: {name:'KoboPay', screens:[
    ['Card management','Card controls and a digital card feature preview.'],
    ['Wallet overview','A wallet dashboard with balance, account actions, and recent activity.'],
    ['Send money','A promotional view of the money-transfer experience.'],
    ['Multiple currencies','The wallet’s currency selection and balance experience.'],
    ['Account dashboard','A unified account view with wallet and card features.'],
    ['Credit feature','A preview of the credit-building feature and progress view.']
  ]},
  HBL: {name:'HBL', screens:[
    ['Account overview','An account dashboard with balance information and banking shortcuts.'],
    ['Easy Mode','A preview of the simplified interface and everyday banking actions.'],
    ['Favorites','Quick access to saved favorites for common payment actions.'],
    ['In-app notifications','The app’s notification experience for banking updates.'],
    ['Smart search','A search experience for finding actions and information in the app.']
  ]},
  Naylam: {name:'Naylam', screens:[
    ['Chauffeur service','An introduction to the luxury transportation service.'],
    ['Full-day bookings','A promotional view of transport for meetings and events.'],
    ['Ride amenities','A service preview featuring Wi-Fi, baby car seats, and mobile chargers.'],
    ['Trip tracking','Trip details and the option to share a journey with loved ones.'],
    ['Booking home','The mobile home screen and available ride services.'],
    ['Country selection','Choose a country before continuing the booking flow.'],
    ['Service selection','Select a ride service and review the booking information.'],
    ['Ride scheduling','Choose a service, date, time, and pickup location.']
  ]},
  Fresha: {name:'Fresha', screens:[
    ['Nearby discovery','Discover salons and spas near a chosen location.'],
    ['Map discovery','A map-based view of beauty and wellness destinations.'],
    ['Salon details','Browse a salon, its services, and appointment options.'],
    ['Professional selection','Choose a professional when booking an appointment.'],
    ['Manage appointments','Review appointments and manage or rebook a visit.'],
    ['Offers and booking','A promotional view of discounts and appointment selection.']
  ]}
};
let galleryFolder = '', galleryCount = 0, galleryIndex = 1, galleryTrigger = null;
function renderGallery() {
  const project = screenCatalog[galleryFolder];
  const [title, description] = project.screens[galleryIndex - 1];
  galleryImage.src = `assets/img/projects/${galleryFolder}/${galleryIndex}.webp`;
  galleryImage.alt = `${project.name}: ${title}`;
  document.querySelector('#gallery-caption-title').textContent = title;
  document.querySelector('#gallery-caption-description').textContent = description;
  document.querySelector('#gallery-counter').textContent = `Screen ${galleryIndex} of ${galleryCount}: ${title}`;
  galleryThumbnails.querySelectorAll('button').forEach((button, index) => {
    const current = index === galleryIndex - 1;
    if (current) button.setAttribute('aria-current','true'); else button.removeAttribute('aria-current');
    button.classList.toggle('is-current',current);
  });
  const selected = galleryThumbnails.children[galleryIndex - 1];
  const left = selected.offsetLeft;
  if (left < galleryThumbnails.scrollLeft) galleryThumbnails.scrollLeft = left;
  else if (left + selected.offsetWidth > galleryThumbnails.scrollLeft + galleryThumbnails.clientWidth) galleryThumbnails.scrollLeft = left + selected.offsetWidth - galleryThumbnails.clientWidth;
}
function moveGallery(direction) { galleryIndex = (galleryIndex - 1 + direction + galleryCount) % galleryCount + 1; renderGallery(); }
function openGallery(button) {
  galleryTrigger = button; galleryFolder = button.dataset.gallery;
  const project = screenCatalog[galleryFolder];
  galleryCount = project.screens.length; galleryIndex = 1;
  document.querySelector('#gallery-title').textContent = project.name;
  // Reuse the published story so the card and viewer always agree.
  const card = button.closest('.ab-project');
  document.querySelector('#gallery-summary').textContent = card.querySelector('.ab-project-description').textContent;
  document.querySelector('#gallery-tags').replaceChildren(...[...card.querySelectorAll('.tp-project-category span')].map(tag => tag.cloneNode(true)));
  document.querySelector('#gallery-details').replaceChildren(...[...card.querySelectorAll('.ab-project-story > div')].map(detail => detail.cloneNode(true)));
  galleryThumbnails.replaceChildren();
  project.screens.forEach(([title],index) => {
    const item = document.createElement('li'), thumb = document.createElement('button'), image = document.createElement('img'), number = document.createElement('span');
    thumb.type = 'button'; thumb.setAttribute('aria-label',`Show screen ${index + 1}: ${title}`); thumb.title = title;
    image.src = `assets/img/thumbnails/${galleryFolder}/${index + 1}.webp`; image.alt = ''; image.width = 52; image.height = 68; image.decoding = 'async';
    number.textContent = String(index + 1).padStart(2,'0');
    thumb.append(image,number); item.append(thumb); galleryThumbnails.append(item);
    thumb.addEventListener('click',() => { galleryIndex = index + 1; renderGallery(); });
  });
  renderGallery();
  dialog.showModal(); dialog.scrollTop = 0;
  document.body.classList.add('modal-open');
  if (smoother) smoother.paused(true);
}
document.querySelectorAll('[data-gallery]').forEach(button => button.addEventListener('click',() => openGallery(button)));
document.querySelector('.gallery-close').addEventListener('click',() => dialog.close());
document.querySelector('.gallery-prev').addEventListener('click',() => moveGallery(-1));
document.querySelector('.gallery-next').addEventListener('click',() => moveGallery(1));
dialog.addEventListener('keydown',event => {
  const isThumb = event.target.closest('#gallery-thumbnails');
  if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); moveGallery(event.key === 'ArrowLeft' ? -1 : 1); if (isThumb) galleryThumbnails.children[galleryIndex - 1].querySelector('button').focus({preventScroll:true}); }
  else if (isThumb && (event.key === 'Home' || event.key === 'End')) { event.preventDefault(); galleryIndex = event.key === 'Home' ? 1 : galleryCount; renderGallery(); galleryThumbnails.children[galleryIndex - 1].querySelector('button').focus({preventScroll:true}); }
});
dialog.addEventListener('click',event => { if (event.target === dialog) { const box=dialog.getBoundingClientRect(); if (event.clientX<box.left || event.clientX>box.right || event.clientY<box.top || event.clientY>box.bottom) dialog.close(); } });
dialog.addEventListener('close',() => { document.body.classList.remove('modal-open'); if (smoother) smoother.paused(false); galleryTrigger?.focus({preventScroll:true}); });
document.querySelector('#year').textContent = new Date().getFullYear();

const motionPreference = matchMedia('(prefers-reduced-motion: reduce)');
const motionButton = document.querySelector('.ab-motion-toggle');
let manualReducedMotion = false;
try { manualReducedMotion = localStorage.getItem('ab-reduce-motion') === 'true'; } catch {}
let reducedMotion = motionPreference.matches || manualReducedMotion;
let motionContext = null;
function syncMotion() {
  reducedMotion = motionPreference.matches || manualReducedMotion;
  document.body.classList.toggle('ab-reduced-motion', reducedMotion);
  motionButton.setAttribute('aria-pressed', String(reducedMotion));
  motionButton.disabled = motionPreference.matches;
  motionButton.textContent = reducedMotion ? 'Reduced motion on' : 'Reduce motion';
}
syncMotion();
function resetMotion() { motionContext?.revert(); motionContext = null; syncMotion(); setupMotion(); }
motionPreference.addEventListener('change', resetMotion);
motionButton.addEventListener('click', () => {
  manualReducedMotion = !manualReducedMotion;
  try { localStorage.setItem('ab-reduce-motion', String(manualReducedMotion)); } catch {}
  resetMotion();
});
const quoteTrack = document.querySelector('.ab-quotes');
function updateQuoteControls() {
  document.querySelector('.quote-prev').disabled = quoteTrack.scrollLeft <= 2;
  document.querySelector('.quote-next').disabled = quoteTrack.scrollLeft >= quoteTrack.scrollWidth - quoteTrack.clientWidth - 2;
}
quoteTrack.addEventListener('scroll', updateQuoteControls, {passive:true});
new ResizeObserver(updateQuoteControls).observe(quoteTrack);
updateQuoteControls();
function moveQuote(direction) { const card = quoteTrack.querySelector('figure'); const gap = parseFloat(getComputedStyle(quoteTrack).gap) || 0; quoteTrack.scrollBy({left: direction * (card.getBoundingClientRect().width + gap), behavior: reducedMotion ? 'auto' : 'smooth'}); }
document.querySelector('.quote-prev').addEventListener('click', () => moveQuote(-1));
document.querySelector('.quote-next').addEventListener('click', () => moveQuote(1));
quoteTrack.addEventListener('keydown', event => { if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') { event.preventDefault(); moveQuote(event.key === 'ArrowRight' ? 1 : -1); } });
let smoother = null;
function setupMotion() {
  if (reducedMotion || motionContext || !window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);
  const mm = gsap.matchMedia();
  motionContext = mm;
  mm.add({desktop:'(min-width: 1100px)', motion:'(prefers-reduced-motion: no-preference)'}, context => {
    if (!context.conditions.motion) return;
    const desktop = context.conditions.desktop;
    if (desktop && window.ScrollSmoother) {
      gsap.registerPlugin(ScrollSmoother);
      smoother = ScrollSmoother.create({wrapper:'#smooth-wrapper',content:'#smooth-content',smooth:.8,effects:true,smoothTouch:false,ignoreMobileResize:true});
    }
    const panels = gsap.utils.toArray('.tp-service-panel');
    if (desktop) panels.slice(0,-1).forEach((panel,index) => ScrollTrigger.create({trigger:panel,start:`top ${90+index*24}`,endTrigger:'.tp-service-pin',end:'bottom bottom',pin:true,pinSpacing:false,invalidateOnRefresh:true}));
    const hero = gsap.timeline({defaults:{ease:'power3.out'}});
    hero.from('.ab-hero-eyebrow',{y:16,opacity:0,duration:.5});
    // Animate complete lines to preserve the image pill and accessible heading text.
    hero.from('.ab-title-line',{yPercent:35,opacity:0,stagger:.11,duration:.85},.12)
      .from('.ab-hero-side',{y:24,opacity:0,duration:.7},.4)
      .from('.ab-hero-bottom',{y:18,opacity:0,duration:.6},.65);
    const reveal = (element, options = {}) => gsap.from(element,{y:desktop?36:22,opacity:0,duration:.75,ease:'power3.out',...options,scrollTrigger:{trigger:element,start:'top 94%',once:true}});
    gsap.utils.toArray('.ab-reveal,.section-heading h2,.about h2,.ab-expertise-title,.ab-intro .tp-about-text,.ab-expertise-intro').forEach(el => reveal(el));
    gsap.utils.toArray('.ab-project').forEach(el => {
      reveal(el,{y:desktop?50:24,duration:.85});
      if (desktop) el.querySelectorAll('.ab-screen').forEach(screen => {
        const rotation=Number(screen.dataset.rotation || 0),drift=Number(screen.dataset.drift || 0);
        gsap.fromTo(screen,{y:drift,rotation},{y:-drift,rotation,ease:'none',scrollTrigger:{trigger:el,start:'top bottom',end:'bottom top',scrub:.6}});
      });
    });
    gsap.utils.toArray('.job').forEach(el => reveal(el));
    gsap.utils.toArray('.tp-service-content').forEach(el => {
      gsap.from(el.querySelectorAll('p,.tp-service-category'),{y:18,opacity:0,stagger:.08,duration:.65,scrollTrigger:{trigger:el,start:'top 88%',once:true}});
    });
    if (desktop) gsap.utils.toArray('.ab-service-symbol').forEach(el => gsap.to(el,{rotation:-8,y:-12,ease:'none',scrollTrigger:{trigger:el.closest('.tp-service-item'),start:'top bottom',end:'bottom top',scrub:.7}}));
    reveal(document.querySelector('.upwork-panel'),{y:32});
    gsap.from('.ab-footer-word',{y:35,opacity:0,duration:.85,scrollTrigger:{trigger:'.ab-footer-word',start:'top 98%',once:true}});
    ScrollTrigger.refresh();
    return () => { if (smoother) { smoother.kill(); smoother = null; } };
  });
}
// Fonts determine the final line lengths; start once layout is ready.
if (document.fonts?.ready) document.fonts.ready.then(setupMotion); else setupMotion();
document.querySelectorAll('a[href^="#"]').forEach(link => link.addEventListener('click', event => {
 const target = document.getElementById(link.getAttribute('href').slice(1));
 if (!target) return;
 event.preventDefault(); closeMenu();
 if (target.matches('section,main')) { target.setAttribute('tabindex','-1'); target.focus({preventScroll:true}); }
 if (smoother && !reducedMotion) smoother.scrollTo(target,true,'top 80px');
 else { const y=target.getBoundingClientRect().top+window.scrollY-70; window.scrollTo({top:y,behavior:reducedMotion?'auto':'smooth'}); }
 history.replaceState(null,'',link.getAttribute('href'));
}));
document.querySelectorAll('.ab-project-stage').forEach(stage => {
 stage.addEventListener('pointermove', event => { if (reducedMotion || event.pointerType !== 'mouse') return; const rect=stage.getBoundingClientRect(); const x=(event.clientX-rect.left)/rect.width-.5; const y=(event.clientY-rect.top)/rect.height-.5; stage.style.setProperty('--hover-x',`${x*8}px`); stage.style.setProperty('--hover-y',`${y*8}px`); });
 stage.addEventListener('pointerleave',()=>{stage.style.removeProperty('--hover-x');stage.style.removeProperty('--hover-y');});
});
